#include "spoj.h"
#include <stdlib.h>

using namespace std;

/* <0-255> normal, -2 eof */
int getChar(FILE *f) {
	int ch;
	if ((ch = getc(f))==EOF) return -2;
	return ch;
}

int main(void) {
	spoj_init();
	int ch1 = getChar(spoj_t_out);
	int ch2 = getChar(spoj_p_out);
	while (ch1 == ch2) {
		if (ch1==-2) return (SPOJ_RV_POSITIVE);
		ch1 = getChar(spoj_t_out);
		ch2 = getChar(spoj_p_out);
	};
	return SPOJ_RV_NEGATIVE;
}

